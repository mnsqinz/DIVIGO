<?php
// DIVIGO API - satu file. PHP 7.4+ dan MySQL/MariaDB. Semua aksi: POST ?a=<aksi> dengan body JSON.
require __DIR__.'/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: '.(defined('ALLOW_ORIGIN')?ALLOW_ORIGIN:'*'));
header('Access-Control-Allow-Headers: Content-Type, X-Token');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Vary: Origin');
if($_SERVER['REQUEST_METHOD']==='OPTIONS'){http_response_code(204);exit;}
function out($d,$c=200){http_response_code($c);echo json_encode($d,JSON_UNESCAPED_UNICODE);exit;}
function fail($m,$c=400){out(['error'=>$m],$c);}
function pdo(){static $p;if(!$p){try{$p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}catch(Exception $e){fail('Koneksi database gagal. Periksa config.php.',500);}}return $p;}
function b64($s){return rtrim(strtr(base64_encode($s),'+/','-_'),'=');}
function sig($p){return b64(hash_hmac('sha256',$p,APP_SECRET,true));}
function tok($role,$id){$p=b64(json_encode(['r'=>$role,'i'=>$id,'e'=>time()+86400*30]));return $p.'.'.sig($p);}
function auth($role){$x=explode('.',$_SERVER['HTTP_X_TOKEN']??'');if(count($x)!==2)fail('Silakan masuk dulu.',401);
 if(!hash_equals(sig($x[0]),$x[1]))fail('Sesi tidak valid.',401);
 $p=json_decode(base64_decode(strtr($x[0],'-_','+/')),true);
 if(!$p||$p['e']<time()||$p['r']!==$role)fail('Sesi berakhir, silakan masuk lagi.',401);return (int)$p['i'];}
$in=json_decode(file_get_contents('php://input'),true);if(!is_array($in))$in=[];
$a=$_GET['a']??'';
switch($a){
case 'siswa_masuk':
 $kode=strtoupper(trim((string)($in['kode']??'')));$nama=trim((string)($in['nama']??''));$pin=(string)($in['pin']??'');
 if($kode===''||$nama===''||!preg_match('/^\d{4}$/',$pin))fail('Isi kode kelas, nama, dan PIN 4 angka.');
 if(mb_strlen($nama)>30)fail('Nama terlalu panjang.');
 $k=pdo()->prepare('SELECT id FROM kelas WHERE kode=?');$k->execute([$kode]);$kid=$k->fetchColumn();
 if(!$kid){sleep(1);fail('Kode kelas belum dikenali. Tanyakan pada gurumu ya.',404);}
 $s=pdo()->prepare('SELECT id,pin_hash FROM siswa WHERE kelas_id=? AND nama=?');$s->execute([$kid,$nama]);$r=$s->fetch();
 if($r){if(!password_verify($pin,$r['pin_hash'])){sleep(1);fail('PIN belum sesuai. Coba lagi ya, atau minta bantuan guru.',403);}$sid=(int)$r['id'];}
 else{pdo()->prepare('INSERT INTO siswa(kelas_id,nama,pin_hash) VALUES(?,?,?)')->execute([$kid,$nama,password_hash($pin,PASSWORD_DEFAULT)]);$sid=(int)pdo()->lastInsertId();}
 $g=pdo()->prepare('SELECT data FROM progres WHERE siswa_id=?');$g->execute([$sid]);$d=$g->fetchColumn();
 out(['token'=>tok('siswa',$sid),'data'=>$d?json_decode($d,true):null,'baru'=>!$r]);
case 'simpan':
 $sid=auth('siswa');$j=$in['data']??null;if(!is_array($j))fail('Data tidak valid.');
 $d=json_encode($j,JSON_UNESCAPED_UNICODE);if(strlen($d)>30000)fail('Data terlalu besar.');
 $pre=isset($j['pre'])&&is_numeric($j['pre'])?(int)$j['pre']:null;
 pdo()->prepare('INSERT INTO progres(siswa_id,data,misi,bintang,pre) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE data=VALUES(data),misi=VALUES(misi),bintang=VALUES(bintang),pre=VALUES(pre)')
  ->execute([$sid,$d,is_array($j['done']??null)?count($j['done']):0,(int)($j['stars']??0),$pre]);
 out(['ok'=>true]);
case 'guru_masuk':
 if(!defined('TEACHER_HASH')||TEACHER_HASH===''||!password_verify((string)($in['password']??''),TEACHER_HASH)){sleep(1);fail('Kata sandi belum sesuai.',403);}
 out(['token'=>tok('guru',1)]);
case 'kelas_buat':
 auth('guru');$nama=trim((string)($in['nama']??''));if($nama===''||mb_strlen($nama)>60)fail('Isi nama kelas.');
 $ab='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
 for($t=0;$t<10;$t++){$kode='';for($i=0;$i<5;$i++)$kode.=$ab[random_int(0,strlen($ab)-1)];
  try{pdo()->prepare('INSERT INTO kelas(kode,nama) VALUES(?,?)')->execute([$kode,$nama]);out(['kode'=>$kode]);}catch(PDOException $e){if($e->getCode()!=='23000')throw $e;}}
 fail('Gagal membuat kode kelas.',500);
case 'kelas_daftar':
 auth('guru');
 out(['kelas'=>pdo()->query('SELECT k.id,k.kode,k.nama,COUNT(s.id) jml FROM kelas k LEFT JOIN siswa s ON s.kelas_id=k.id GROUP BY k.id ORDER BY k.id DESC')->fetchAll()]);
case 'rekap':
 auth('guru');$q=pdo()->prepare('SELECT s.id,s.nama,p.data,p.updated FROM siswa s LEFT JOIN progres p ON p.siswa_id=s.id WHERE s.kelas_id=? ORDER BY s.nama');$q->execute([(int)($in['kelas_id']??0)]);
 $rows=$q->fetchAll();foreach($rows as &$r){$r['data']=$r['data']?json_decode($r['data'],true):null;}
 out(['siswa'=>$rows]);
case 'siswa_pin':
 auth('guru');$pin=(string)($in['pin']??'');if(!preg_match('/^\d{4}$/',$pin))fail('PIN harus 4 angka.');
 pdo()->prepare('UPDATE siswa SET pin_hash=? WHERE id=?')->execute([password_hash($pin,PASSWORD_DEFAULT),(int)($in['id']??0)]);out(['ok'=>true]);
case 'siswa_hapus':
 auth('guru');pdo()->prepare('DELETE FROM siswa WHERE id=?')->execute([(int)($in['id']??0)]);out(['ok'=>true]);
default: fail('Aksi tidak dikenal.',404);
}
