<?php
// Salin file ini menjadi config.php lalu isi. Jangan unggah config.php ke repository publik.
define('DB_HOST','localhost');
define('DB_NAME','divigo');
define('DB_USER','root');
define('DB_PASS','');
// Teks acak panjang untuk menandatangani sesi. Buat: php -r "echo bin2hex(random_bytes(32));"
define('APP_SECRET','GANTI-DENGAN-TEKS-ACAK-PANJANG');
// Hash kata sandi guru. Buat: php -r "echo password_hash('SandiGuruAnda',PASSWORD_DEFAULT);"
define('TEACHER_HASH','');
// Alamat situs yang boleh memanggil API, mis. https://akun.github.io (tanpa garis miring akhir). Jika satu server, boleh '*'.
define('ALLOW_ORIGIN','*');
